const defaultRoutes = [];

export default defaultRoutes;
