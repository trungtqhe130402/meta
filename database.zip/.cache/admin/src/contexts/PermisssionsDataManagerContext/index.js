import { createContext } from 'react';

const PermissionsDataManagerContext = createContext({});

export default PermissionsDataManagerContext;
