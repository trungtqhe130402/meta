import { createContext } from 'react';

const ThemeToggleContext = createContext({});

export default ThemeToggleContext;
