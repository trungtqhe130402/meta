import styled from 'styled-components';

const Container = styled.div`
  padding: 18px 30px 66px 30px;
`;

export default Container;
